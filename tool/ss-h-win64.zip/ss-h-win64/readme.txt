使用nexe打包
nexe local.js -t "windows-x64-4.8.4" -n ss-h

一键部署heroku服务端 https://github.com/onplus/shadowsocks-heroku#%E4%BA%8C%E9%83%A8%E7%BD%B2

修改config.json参数，双击ss-h.exe运行或者start.vbs后台运行

推荐chrome/firefox + switchyomega
